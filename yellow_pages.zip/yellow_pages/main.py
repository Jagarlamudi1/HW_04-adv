from fileinput import filename
import os
from select import select
from click import confirm
from flask import Flask, flash, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy




app = Flask(__name__, template_folder='templates', static_folder='static')
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///yellow.sqlite"

db=SQLAlchemy(app)



class Company(db.Model):
    name=db.Column(db.String(20), nullable= False)
    id=db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(20),  nullable=False)
    contact = db.Column(db.String(20),  nullable=False)
    address = db.Column(db.String(20),  nullable=False)

   


@app.route('/home')
def page():
    return render_template('index.html')

@app.route('/update/<id>', methods=["POST", "GET"])
def update(id):
    data= Company.query.get_or_404(id)
    if request.method =="POST":
       data.name=request.form.get('company_name')
       data.email=request.form.get('email')
       data.contact=request.form.get('number')
       data.address=request.form.get('address')
       try:
            db.session.commit()
            flash('data has been updated')
            return redirect(url_for('list_companies'))
       except:
            flash('error!!, there was a problem')
            return redirect(url_for('update', id=data.id))

    return render_template('update.html', data= data)

@app.route('/delete/<id>')
def delete(id):
    data= Company.query.get_or_404(id)
    try :
        db.session.delete(data)
        db.session.commit()
        flash('data deleted')
        return redirect(url_for('list_companies'))
    except Exception:
        flash('id does not exist')
        return redirect(url_for('list_companies'))



@app.route('/addcompany', methods=["POST", "GET"])
def add_company():
    if request.method =="POST":
       name=request.form.get('company_name')
       email=request.form.get('email')
       contact=request.form.get('number')
       address=request.form.get('address')
       details=Company(name=name, email=email, contact=contact, address=address)
       db.session.add(details)
       db.session.commit()
       return redirect(url_for('page'))
    else:
        return render_template('add_company.html')

@app.route('/companies', methods=["POST", "GET"])
def list_companies():
    data_company=Company.query.all()
    if not data_company:
        flash('no company has been listed')
        return render_template('companies.html')
      
    if request.method == "POST":
        number = request.form.get('number')
        new_data=Company.query.filter_by(contact=number).first()
        if new_data:
            return render_template('companies.html', new_data=new_data)
        else:
            flash('no data found')
            return render_template('companies.html')
    else:
        return render_template('companies.html', data=data_company)



app.secret_key= "sfjfdjd"
app.run(debug=True)
